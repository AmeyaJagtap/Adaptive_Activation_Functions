#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Mar 23 22:08:49 2019
@author: Dr. Ameya D. Jagtap, Brown University, RI 02912, USA.

Description: 
We introduced the adaptive slope parameter (a) for activation function, which can be trained with
other parameters. Such adaptive activation functions are shown to accelerate the convergence in the neural 
network training. 

Reference: 
1. Adaptive activation functions accelerate convergence in deep and physics-informed neural networks, 
Journal of Computational Physics, Vol. 404, 109136, 2020. [MAIN]

2. A.D.Jagtap, K.Kawaguchi, G.E.Karniadakis, Locally adaptive activation functions with slope recovery for deep 
and physics-informed neural networks,
Proceedings of the Royal Society A: Mathematical, Physical and Engineering Sciences, 20200334, 2020. [EXTENSION 1]

3. A.D. Jagtap, Y. Shin, K. Kawaguchi, G.E. Karniadakis, Deep Kronecker neural networks: A general framework
 for neural networks with adaptive activation functions, 
 Neurocomputing, 468, 165-180, 2022.  [EXTENSION 2]

"""

import sys
#sys.path.insert(0, '../../Utilities/')

import tensorflow as tf
import numpy as np
#import pandas as pd
import matplotlib.pyplot as plt
import scipy.io
from scipy.interpolate import griddata
from pyDOE import lhs
#from plotting import newfig, savefig
#from mpl_toolkits.mplot3d import Axes3D
import time
import matplotlib.gridspec as gridspec
from mpl_toolkits.axes_grid1 import make_axes_locatable

np.random.seed(1234)
tf.set_random_seed(1234)

class PhysicsInformedNN:
    # Initialize the class


    def __init__(self, X_u, u, X_f, layers, lb, ub, beta,nu):
        
        self.lb = lb
        self.ub = ub
    
        self.x_u = X_u[:,0:1]
        self.t_u = X_u[:,1:2]
        
        self.x_f = X_f[:,0:1]
        self.t_f = X_f[:,1:2]
        
        self.u = u
        
        self.layers = layers
        self.beta = beta
        self.nu = nu
       
        # Initialize NNs
        self.weights, self.biases, self.a = self.initialize_NN(layers)
        
        # tf placeholders and graph
        self.sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True,
                                                     log_device_placement=True))
        
        self.x_u_tf = tf.placeholder(tf.float32, shape=[None, self.x_u.shape[1]])
        self.t_u_tf = tf.placeholder(tf.float32, shape=[None, self.t_u.shape[1]])        
        self.u_tf = tf.placeholder(tf.float32, shape=[None, self.u.shape[1]])
        
        self.x_f_tf = tf.placeholder(tf.float32, shape=[None, self.x_f.shape[1]])
        self.t_f_tf = tf.placeholder(tf.float32, shape=[None, self.t_f.shape[1]])        
                
        self.u_pred = self.net_u(self.x_u_tf, self.t_u_tf) 
        self.f_pred = self.net_f(self.x_f_tf, self.t_f_tf)   
      
        self.loss = tf.reduce_mean(tf.square(self.u_tf - self.u_pred)) + \
                    tf.reduce_mean(tf.square(self.f_pred))
               
                
        self.optimizer = tf.contrib.opt.ScipyOptimizerInterface(self.loss, 
                                                                method = 'L-BFGS-B', 
                                                                options = {'maxiter': 2000,
                                                                           'maxfun': 2000,
                                                                           'maxcor': 50,
                                                                           'maxls': 50,
                                                                           'ftol' : 1.0 * np.finfo(float).eps})
        
        self.optimizer_Adam = tf.train.AdamOptimizer(0.0008)
        self.train_op_Adam = self.optimizer_Adam.minimize(self.loss)    
    
        init = tf.global_variables_initializer()
        self.sess.run(init)
                
    def initialize_NN(self, layers):        
        weights = []
        biases = []
        num_layers = len(layers) 
        for l in range(0,num_layers-1):
            W = self.xavier_init(size=[layers[l], layers[l+1]])
            b = tf.Variable(tf.zeros([1,layers[l+1]], dtype=tf.float32), dtype=tf.float32)
            weights.append(W)
            biases.append(b) 
        # Adaptive Activation Slope parameter    
        a = tf.Variable(0.1, dtype=tf.float32)

        return weights, biases, a
         
    def xavier_init(self, size):
        in_dim = size[0]
        out_dim = size[1]        
        xavier_stddev = np.sqrt(2/(in_dim + out_dim))
        return tf.Variable(tf.truncated_normal([in_dim, out_dim], stddev=xavier_stddev), dtype=tf.float32)
    
    def neural_net(self, X, weights, biases, a):
        num_layers = len(weights) + 1
        
        H = 2.0*(X - self.lb)/(self.ub - self.lb) - 1.0
        for l in range(0,num_layers-2):
            W = weights[l]
            b = biases[l] 
            # Scaling factor (n) = 10, which satisfies (n*a = 1) condition
            H = tf.tanh(10*a*tf.add(tf.matmul(H, W), b))
        W = weights[-1]
        b = biases[-1]
        Y = tf.add(tf.matmul(H, W), b)
        return Y
            
    def net_u(self, x, t):
        u = self.neural_net(tf.concat([x,t],1), self.weights, self.biases, self.a)
        return u
    
    def net_f(self, x,t):
        u = self.net_u(x,t)
        u_t = tf.gradients(u, t)[0]
        u_x = tf.gradients(u, x)[0]
        u_xx = tf.gradients(u_x, x)[0]
        f = u_t + u*u_x - self.nu*u_xx
        
        return f
    
    def callback(self, loss):
        print('Loss:', loss)
        
    def train(self,nIter):
        
        tf_dict = {self.x_u_tf: self.x_u, self.t_u_tf: self.t_u, self.u_tf: self.u,
                   self.x_f_tf: self.x_f, self.t_f_tf: self.t_f}
                                                                  

        MSE_history=[]
        a_history=[]
        for it in range(nIter):
            self.sess.run(self.train_op_Adam,tf_dict)
            
            if it %50 == 0:
#                elapsed = time.time() - start_time
                loss_value = self.sess.run(self.loss, tf_dict)
                a_value = self.sess.run(self.a, tf_dict)
                print('It: %d, Loss: %.3e, a_value: %.3e' % 
                      (it, loss_value, a_value))
#                start_time = time.time()
                MSE_history.append(loss_value)
                a_history.append(a_value)


                
        
                                                        
        self.optimizer.minimize(self.sess, 
                                feed_dict = tf_dict,         
                                fetches = [self.loss], 
                                loss_callback = self.callback)        
                                    
        return MSE_history, a_history 
    
    def predict(self, X_star):
                
        u_star = self.sess.run(self.u_pred, {self.x_u_tf: X_star[:,0:1], self.t_u_tf: X_star[:,1:2]})  
        f_star = self.sess.run(self.f_pred, {self.x_f_tf: X_star[:,0:1], self.t_f_tf: X_star[:,1:2]})
               
        return u_star, f_star
    
if __name__ == "__main__": 
     
    beta = 1e-7
    noise = 0.0  
    nu = 0.01/np.pi      

    N_u = 200
    N_f = 10000
    layers = [2, 20, 20, 20, 20, 20, 20, 1]
    
    data = scipy.io.loadmat('burgers_shock.mat')
    
    t = data['t'].flatten()[:,None]
    x = data['x'].flatten()[:,None]
    Exact = np.real(data['usol']).T
    
    X, T = np.meshgrid(x,t)
    
    X_star = np.hstack((X.flatten()[:,None], T.flatten()[:,None]))
    u_star = Exact.flatten()[:,None]              

    # Domain bounds
    lb = X_star.min(0)
    ub = X_star.max(0)    
        
    xx1 = np.hstack((X[0:1,:].T, T[0:1,:].T))
    uu1 = Exact[0:1,:].T
    xx2 = np.hstack((X[:,0:1], T[:,0:1]))
    uu2 = Exact[:,0:1]
    xx3 = np.hstack((X[:,-1:], T[:,-1:]))
    uu3 = Exact[:,-1:]
    
    
    
    X_u_train = np.vstack([xx1, xx2, xx3])#, X_star])
    X_f_train = lb + (ub-lb)*lhs(2, N_f)
    X_f_train = np.vstack((X_f_train, X_u_train))
    u_train = np.vstack([uu1, uu2, uu3])#, u_star])
    
    idx = np.random.choice(X_u_train.shape[0], N_u, replace=False)
    X_u_train = X_u_train[idx, :]
    u_train = u_train[idx,:]
        
    model = PhysicsInformedNN(X_u_train, u_train, X_f_train, layers, lb, ub, beta,nu)
    
    Max_iter = 2000
    start_time = time.time()                
    MSE_hist, a_hist = model.train(Max_iter)
    elapsed = time.time() - start_time                
    print('Training time: %.4f' % (elapsed))
    
    u_pred, f_pred = model.predict(X_star)
            
    error_u = np.linalg.norm(u_star-u_pred,2)/np.linalg.norm(u_star,2)
    print('Error u: %e' % (error_u))                     

    
    U_pred = griddata(X_star, u_pred.flatten(), (X, T), method='cubic')
    Error = np.abs(Exact - U_pred)
    
    #%%
    ######################################################################
    ############################# Plotting ###############################
    ###################################################################### 
    # Plotting na vs Adam Epochs for every 50 iteration steps.
    a_hist = np.reshape(a_hist, (-1, 1)) 
    fig = plt.figure(1)
    plt.plot(range(0,Max_iter, 50), 10*a_hist,  'b-', linewidth = 1) 
    plt.xlabel('Adam Epochs')
    plt.ylabel('$na$')
    plt.savefig('./figures/Bur_Ahistory.pdf') 
    
    # Plotting Adam Loss vs Adam Epochs for every 50 iteration steps.
    fig = plt.figure(2)
    plt.plot(range(0,Max_iter, 50), MSE_hist,  'r-', linewidth = 1) 
    plt.xlabel('Adam Epochs')
    plt.ylabel('Adam Loss')
    plt.yscale('log')
    plt.savefig('./figures/Bur_MSEhistory.pdf') 

    
    ######################################################################    
 
    #%% Predicted solution and Point-wise error in the entire space-time domain
    fig = plt.figure(3)
    gridspec.GridSpec(1,1)
   
    ax = plt.subplot2grid((1,1), (0,0))
    CS_pred1 = ax.contourf(T, X, U_pred, 200, cmap='jet', origin='lower')
    cbar = fig.colorbar(CS_pred1)
    cbar.ax.tick_params(labelsize=18)
    ax.set_xlabel('$t$', fontsize = 22)
    ax.set_ylabel('$x$', fontsize = 22)
    ax.set_title('$ u $ (predicted)', fontsize = 24)
    ax.tick_params(axis="x", labelsize = 18)
    ax.tick_params(axis="y", labelsize = 18)
   
    fig.set_size_inches(w=12,h=6)
    plt.savefig('./figures/Burgers_Pred.pdf') 
    #%
    # Pointwise error
    fig = plt.figure(4)
    gridspec.GridSpec(1,1)
   
    ax = plt.subplot2grid((1,1), (0,0))
    CS_pred1 = ax.contourf(T, X, Error, 200, cmap='jet', origin='lower')
    cbar = fig.colorbar(CS_pred1)
    cbar.ax.tick_params(labelsize=18)
    ax.set_xlabel('$t$', fontsize = 22)
    ax.set_ylabel('$x$', fontsize = 22)
    ax.set_title('$ u $ (Point-wise error)', fontsize = 24)
    ax.tick_params(axis="x", labelsize = 18)
    ax.tick_params(axis="y", labelsize = 18)
   
    fig.set_size_inches(w=12,h=6)
    plt.savefig('./figures/Burgers_Err.pdf') 

